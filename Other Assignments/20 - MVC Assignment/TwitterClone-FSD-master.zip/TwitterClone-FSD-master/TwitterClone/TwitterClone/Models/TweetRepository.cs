﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwitterClone.Models
{
    public class TweetRepository
    {
        //public static List<Tweet> tweetList = new List<Tweet>()
        //{
        //    new Tweet(){ TweetId=1,Username="u101",Message="Hello how are you ?", Created=DateTime.Now},
        //    new Tweet(){ TweetId=2,Username="u102",Message="How was your work ?", Created=DateTime.Now},
        //    new Tweet(){ TweetId=3,Username="u101",Message="Hope you had a great weekend ?", Created=DateTime.Now},
        //    new Tweet(){ TweetId=4,Username="u103",Message="Have a nice evening ?", Created=DateTime.Now},
        //    new Tweet(){ TweetId=5,Username="u101",Message="Get well soon ?", Created=DateTime.Now},
        //    new Tweet(){ TweetId=6,Username="u104",Message="Shall we meet tomorrow ?", Created=DateTime.Now}
        //};
    }
}