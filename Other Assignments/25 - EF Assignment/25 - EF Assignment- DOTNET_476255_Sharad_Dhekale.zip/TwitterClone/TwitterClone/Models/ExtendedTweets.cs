﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwitterClone.Models
{
    public partial class Tweet
    {
        public string tweetText { get; set; }
    }
}