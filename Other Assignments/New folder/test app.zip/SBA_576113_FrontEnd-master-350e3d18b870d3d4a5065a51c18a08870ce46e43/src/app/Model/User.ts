export class User{
    UserId:number;
    FirstName:string;
    LastName:string;
    EmployeeId:number; 
}